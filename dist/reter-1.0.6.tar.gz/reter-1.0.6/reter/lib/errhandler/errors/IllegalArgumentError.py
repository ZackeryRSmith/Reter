from reter.lib.errhandler.handle import Error


########################################
# ILLEGAL ARGUMENT ERROR
########################################

class IllegalArgumentError(Error):
    """Called when a argument unbeknown to us gets passed"""
    pass
