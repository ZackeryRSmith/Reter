from reter.lib.errhandler.handle import Error


########################################
# UNEXPECTED RESULT
########################################

class UnexpectedResult(Error):
    """Called when a argument unbeknown to us gets passed"""
    pass

